<!-- HOSSAINY Said et DIAGNE Salla -->

<?php
	ini_set("display_errors",1);

	try {
		$connexion = new PDO("pgsql:host=localhost;dbname=projetTW","diagne","robben10", array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
	}
	catch (PDOException $e) {
		echo("Erreur connexion :". $e->getMessage());
	}
?>