<?php
	echo(levenshtein("carie","durite"));
/*
	let construire_table u v =
	let n = String.length u and m = String.length v
	in
	let table = Array.make_matrix (n + 1) (m + 1) 0
	in
	for i = 0 to n do
		for j = 0 to m do
			if i = 0 then
				table.(i).(j) <- j
			else
			if j = 0 then
				table.(i).(j) <- i
			else
			if u.[i-1] = v.[j-1] then
				table.(i).(j) <- table.(i-1).(j-1)
			else
			table.(i).(j) <- 1 + min (min table.(i-1).(j-1) table.(i).(j-1)) table.(i-1).(j)
		done;
	done;
	table*/

?>