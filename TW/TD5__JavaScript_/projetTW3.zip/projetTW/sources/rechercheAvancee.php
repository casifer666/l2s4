<!-- HOSSAINY Said et DIAGNE Salla -->

<?php
	include('connect.php');
	include_once('Commune.class.php');
	if (isset($_POST['commune']) || isset($_POST['code']) || isset($_POST['departement']) || isset($_POST['region']) || isset($_POST['pop_min']) || isset($_POST['pop_max'])) {
		if ($_POST['commune'] == "" && $_POST['code'] == "" && $_POST['departement'] == "" && $_POST['region'] == "" && $_POST['pop_min'] == "" && $_POST['pop_max'] == "") {
			unset($_SESSION['total']);
			echo("<script> afficherAlerte(); </script>");
		}
		else {
			$champs = array();
			$i = 0;
			if ($_POST['commune'] != "") {
				$entree = strtoupper($_POST['commune']);
				$entree = str_replace(array("â","à","ä","ç","é","è","ê","ë","î","ï","ô","ö","œ","û","ü","Â","À","Ä","Ç","É","È","Ê","Ë","Î","Ï","Ô","Ö","Œ","Û","Ü","'"),
					array("A","A","A","C","E","E","E","E","I","I","O","O","OE","U","U","A","A","A","C","E","E","E","E","I","I","O","O","OE","U","U","''"),$entree);
				$champs[$i] = "nom_ascii_maj IN (SELECT regexp_split_to_table('".$entree."', ' '))"; $i++;
			}
			if ($_POST['code'] != "") {
				$champs[$i] = "dept||comm='".$_POST['code']."'"; $i++;
			}
			if($_POST['departement'] != "") {
				$champs[$i] = "dept='".$_POST['departement']."'"; $i++;
			}
			if ($_POST['region'] != "") {
				$champs[$i] = "region='".$_POST['region']."'"; $i++;
			}
			if ($_POST['pop_min'] != "") {
				$champs[$i] = "population >='".$_POST['pop_min']."'"; $i++;
			}
			if ($_POST['pop_max'] != "") {
				$champs[$i] = "population <='".$_POST['pop_max']."'"; $i++;
			}
			echo("<script> afficherResultats(); </script>");
			$resultats = $connexion->query("SELECT * FROM communes WHERE ".implode(" AND ",$champs)."ORDER BY nom");
			if ($resultats->rowCount() == 0) {
				echo('<div id="null" style="color : black"> <a> Aucune commune ne correspond à votre recherche </a> </div>');
				echo("<script> nombreResultats(0); </script>");
			}
			else {
				$_SESSION['url'] =$_SERVER['REQUEST_URI'];
				$totalResultats = $resultats->rowCount();
				$nbreDePages = ceil($totalResultats / 15);
				$_SESSION['requete'] = "SELECT * FROM communes WHERE ".implode(" AND ",$champs);
				$_SESSION['total'] = $totalResultats;
				$_SESSION['nbreDePages'] = $nbreDePages;
				$_SESSION['page'] = $_GET['page'];
				$resultats = $connexion->query("SELECT * FROM communes WHERE ".implode(" AND ",$champs)." ORDER BY nom ASC LIMIT 15
												OFFSET ".(($_GET['page'] - 1) * 15));
				while ($tableau = $resultats->fetch()) {
					$uneCommune = new Commune($tableau['nom'],$tableau['dept'],$tableau['comm'],$tableau['region'],
								$tableau['latitude'],$tableau['longitude'],$tableau['tncc'],$tableau['population']);
					$uneCommune->afficheResultat();
				}
				echo("<script> window.addEventListener('load',ajouterMarqueur,false); nombreResultats(".$totalResultats."); </script>");
			}
		}
	}

	if (isset($_GET['debut']) && !isset($_GET['rr'])) {
		echo("test");
		echo("<script> afficherResultats(); </script>");
		$_SESSION['url'] = $_SERVER['REQUEST_URI'];
		$ligneCourante = (($_GET['page'] - 1) * 15);
		$resultats = $connexion->query($_SESSION['requete']." ORDER BY nom ASC LIMIT 15 OFFSET ".(($_GET['page'] - 1) * 15));
		while ($tableau = $resultats->fetch()) {
					$uneCommune = new Commune($tableau['nom'],$tableau['dept'],$tableau['comm'],$tableau['region'],
								$tableau['latitude'],$tableau['longitude'],$tableau['tncc'],$tableau['population']);
					$uneCommune->afficheResultat();
		}
	//	echo("<script> window.addEventListener('load',ajouterMarqueur,false); nombreResultats(".$_SESSION['total']."); </script>");
	}
?>