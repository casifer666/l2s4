package naval;

/**
 * Type permettant de representer les 3 reponses possibles apres une proposition d'un attaquant
 */
public enum Reponse {
	DANS_LEAU,
	TOUCHE,
	COULE;
}
